package vn.edu.tlu.cse.tranvanchien.myapplication;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.stream.Collectors;

public class TrainingPointsActivity extends AppCompatActivity {
    private ListView lvStudents;
    private DatabaseHelper dbHelper;
    private ArrayList<HashMap<String, String>> studentList;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_training_points);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        lvStudents = findViewById(R.id.lvStudents);
        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getReadableDatabase();

        loadStudents();

        lvStudents.setOnItemClickListener((parent, view, position, id) -> {
            HashMap<String, String> student = studentList.get(position);
            showPointsDialog(student);
        });
    }

    private void loadStudents() {
        studentList = dbHelper.getAllStudents();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
                studentList.stream().map(s -> s.get("fullname") + " - " + s.get("training_points")).collect(Collectors.toList()));
        lvStudents.setAdapter(adapter);
    }

    private void showPointsDialog(HashMap<String, String> student) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_training_points, null);
        builder.setView(dialogView);
        builder.setTitle("Sửa điểm rèn luyện: " + student.get("fullname"));

        EditText etPoints = dialogView.findViewById(R.id.etTrainingPoints);
        etPoints.setText(student.get("training_points").equals("null") ? "" : student.get("training_points"));

        builder.setPositiveButton("Lưu", (dialog, which) -> {
            try {
                float points = Float.parseFloat(etPoints.getText().toString().trim());
                if (points < 0 || points > 100) {
                    Toast.makeText(this, "Điểm phải từ 0 đến 100", Toast.LENGTH_SHORT).show();
                    return;
                }
                dbHelper.updateTrainingPoints(student.get("student_id"), points);
                loadStudents();
                // Trả về kết quả để TeacherActivity cập nhật
                Intent resultIntent = new Intent();
                setResult(RESULT_OK, resultIntent);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Vui lòng nhập số hợp lệ", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Hủy", null);
        builder.show();
    }}

