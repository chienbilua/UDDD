package vn.edu.tlu.cse.tranvanchien.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;

public class ScheduleActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private String studentId;
    private RecyclerView rvSchedule;
    private ScheduleAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        dbHelper = new DatabaseHelper(this);
        studentId = getIntent().getStringExtra("STUDENT_ID");

        rvSchedule = findViewById(R.id.rvSchedule);
        rvSchedule.setLayoutManager(new LinearLayoutManager(this));

        ArrayList<HashMap<String, String>> scheduleList = dbHelper.getStudentSchedule(studentId);
        adapter = new ScheduleAdapter(scheduleList);
        rvSchedule.setAdapter(adapter);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    private static class ScheduleAdapter extends RecyclerView.Adapter<ScheduleAdapter.ViewHolder> {
        private final ArrayList<HashMap<String, String>> scheduleList;

        ScheduleAdapter(ArrayList<HashMap<String, String>> scheduleList) {
            this.scheduleList = scheduleList;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(android.R.layout.simple_list_item_2, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            HashMap<String, String> schedule = scheduleList.get(position);
            holder.tvSubject.setText(schedule.get("subject"));
            holder.tvDetails.setText(schedule.get("time") + " - " + schedule.get("room"));
        }

        @Override
        public int getItemCount() {
            return scheduleList.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvSubject, tvDetails;

            ViewHolder(View itemView) {
                super(itemView);
                tvSubject = itemView.findViewById(android.R.id.text1);
                tvDetails = itemView.findViewById(android.R.id.text2);
            }
        }
    }
}