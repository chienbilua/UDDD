package vn.edu.tlu.cse.tranvanchien.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.HashMap;

public class StudentActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private String studentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        dbHelper = new DatabaseHelper(this);
        studentId = getIntent().getStringExtra("STUDENT_ID");

        // Kiểm tra studentId
        if (studentId == null || studentId.isEmpty()) {
            Toast.makeText(this, "Không tìm thấy mã sinh viên. Vui lòng đăng nhập lại.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Hiển thị thông tin sinh viên
        TextView tvStudentId = findViewById(R.id.tvStudentId);
        TextView tvFullName = findViewById(R.id.tvFullName);
        TextView tvClass = findViewById(R.id.tvClass);
        TextView tvGender = findViewById(R.id.tvGender);
        TextView tvTrainingPoints = findViewById(R.id.tvTrainingPoints);
        TextView tvConduct = findViewById(R.id.tvConduct);

        HashMap<String, String> studentInfo = dbHelper.getStudentInfo(studentId);
        if (studentInfo.isEmpty()) {
            Toast.makeText(this, "Không tìm thấy thông tin sinh viên.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        tvStudentId.setText("Mã sinh viên: " + studentInfo.get("student_id"));
        tvFullName.setText("Họ tên: " + studentInfo.get("fullname"));
        tvClass.setText("Lớp: " + studentInfo.get("class"));
        tvGender.setText("Giới tính: " + studentInfo.get("gender"));

        // Hiển thị điểm rèn luyện và hạnh kiểm
        String trainingPoints = studentInfo.get("training_points");
        String conduct = studentInfo.get("conduct");
        tvTrainingPoints.setText("Điểm rèn luyện: " + (trainingPoints.equals("null") ? "Chưa có" : trainingPoints));
        tvConduct.setText("Hạnh kiểm: " + (conduct.equals("null") ? "Chưa có" : conduct));

        // Xử lý nút Bảng điểm
        Button btnTranscript = findViewById(R.id.btnTranscript);
        btnTranscript.setOnClickListener(v -> {
            Intent intent = new Intent(StudentActivity.this, TranscriptActivity.class);
            intent.putExtra("STUDENT_ID", studentId);
            startActivity(intent);
        });

        // Xử lý nút Lịch học
        Button btnSchedule = findViewById(R.id.btnSchedule);
        btnSchedule.setOnClickListener(v -> {
            Intent intent = new Intent(StudentActivity.this, ScheduleActivity.class);
            intent.putExtra("STUDENT_ID", studentId);
            startActivity(intent);
        });

        // Xử lý nút Đăng xuất
        Button btnLogout = findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(StudentActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}