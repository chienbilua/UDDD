package vn.edu.tlu.cse.tranvanchien.myapplication;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.stream.Collectors;

public class ConductActivity extends AppCompatActivity {
    private ListView lvStudents;
    private DatabaseHelper dbHelper;
    private ArrayList<HashMap<String, String>> studentList;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conduct);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        lvStudents = findViewById(R.id.lvStudents);
        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getReadableDatabase();

        loadStudents();

        lvStudents.setOnItemClickListener((parent, view, position, id) -> {
            HashMap<String, String> student = studentList.get(position);
            showConductDialog(student);
        });
    }

    private void loadStudents() {
        studentList = dbHelper.getAllStudents();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
                studentList.stream().map(s -> s.get("fullname") + " - " + s.get("conduct")).collect(Collectors.toList()));
        lvStudents.setAdapter(adapter);
    }

    private void showConductDialog(HashMap<String, String> student) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Sửa hạnh kiểm: " + student.get("fullname"));
        String[] options = {"Tốt", "Khá", "Trung bình", "Yếu"};
        builder.setItems(options, (dialog, which) -> {
            String conduct = options[which];
            dbHelper.updateConduct(student.get("student_id"), conduct);
            loadStudents();
            // Trả về kết quả để TeacherActivity cập nhật
            Intent resultIntent = new Intent();
            setResult(RESULT_OK, resultIntent);
        });
        builder.setNegativeButton("Hủy", null);
        builder.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (db != null && db.isOpen()) {
            db.close();
        }
    }
}